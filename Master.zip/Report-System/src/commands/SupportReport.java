package commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import main.Main;

public class SupportReport implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player)sender;
		if(sender instanceof Player){
			if(p.hasPermission("reportmanager.message")){
			if(args.length == 1){
				String target = args[0];
		 for(Player all : Bukkit.getOnlinePlayers()){
			 if(all.hasPermission("reportmanager.message")){
				p.sendMessage(Main.Prefux + "�a" + p.getName() + " �6k�mmert sich um den gereporteten Spieler �4" + target); 
			 }
		 }
			}	
			
			}	
		}
		return false;
	}
}