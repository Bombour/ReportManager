package commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import main.Main;

public class ListReports implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player)sender;
		if(sender instanceof Player){
			if(p.hasPermission("reportmanager.message")){
				String Reports = Main.allereports.toString();
				p.sendMessage(Main.Prefux + Reports);
			}
		}
		return false;
	}

}
