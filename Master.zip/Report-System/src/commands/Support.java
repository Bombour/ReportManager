package commands;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import org.bukkit.event.inventory.InventoryClickEvent;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import main.Main;

public class Support implements CommandExecutor, Listener {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player p = (Player)sender;
		if(sender instanceof Player){
			if(args.length == 1){
				if(p.hasPermission("reportmanager.message")){
				String target = args[0];
				if(Main.Supportmodus.size() ==1){
			    	Main.Supportmodus.remove(0);
			    	System.out.println(Main.Prefux + "�6Supporttarget List ges�ubert.");
			    }
			   Main.Supportmodus.add(target);
			   System.out.println(Main.Prefux + "Supporttarget hinzufgef�gt.");
			   opensupportgui(p);
			   for(Player all:Bukkit.getOnlinePlayers()){
				   if(all.hasPermission("reportmanager.admin")){
					   all.sendMessage(Main.Prefux + "�e" + p.getName() + "�5hat das Support Inventar f�r das target �4" + target + " �5ge�ffnet!");
				   }
			   }
			}	
			}
		}
		return false;
	}
	
	
	Inventory inv1 = Bukkit.createInventory(null, 9, "�4Support");
	
	public void opensupportgui(Player p){
		
		ItemStack item = new ItemStack(Material.ENDER_PEARL);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName("�eTeleport-Gamemode3");
		item.setItemMeta(meta);
		
		ItemStack item1 = new ItemStack(Material.WOOD_SWORD);
		ItemMeta meta1 = item1.getItemMeta();
		meta1.setDisplayName("�eR�cksto�");
		item1.setItemMeta(meta1);
		
		ItemStack item2 = new ItemStack(Material.ARROW);
		ItemMeta meta2 = item2.getItemMeta();
		meta2.setDisplayName("�eFly=false");
		item2.setItemMeta(meta2);
		
		ItemStack item3 = new ItemStack(Material.PAPER);
		ItemMeta meta3 = item3.getItemMeta();
		meta3.setDisplayName("�eWarnung");
		item3.setItemMeta(meta3);
		
		ItemStack item4 = new ItemStack(Material.SKULL_ITEM);
		ItemMeta meta4 = item4.getItemMeta();
		meta4.setDisplayName("�4Kick");
		item4.setItemMeta(meta4);
		
		ItemStack item5 = new ItemStack(Material.BOOK);
		ItemMeta meta5 = item.getItemMeta();
		meta5.setDisplayName("�4Tempban-Chatverhalten");
		item5.setItemMeta(meta5);
		
		ItemStack item6 = new ItemStack(Material.BOOK_AND_QUILL);
		ItemMeta meta6 = item6.getItemMeta();
		meta6.setDisplayName("�4Tempban-Fly/Speed");
		item6.setItemMeta(meta6);
		
		ItemStack item7 = new ItemStack(Material.DEAD_BUSH);
		ItemMeta meta7 = item7.getItemMeta();
		meta7.setDisplayName("�4Ban-Killaura/etc");
		item7.setItemMeta(meta7);
		
		ItemStack item8 = new ItemStack(Material.SKULL_ITEM);
		ItemMeta meta8 = item8.getItemMeta();
		meta8.setDisplayName("�4IpBan-Severkiller/multiacc+hacking");
		item8.setItemMeta(meta8);
		
		inv1.setItem(0, item);
		inv1.setItem(1, item1);
		inv1.setItem(2, item2);
		inv1.setItem(3, item3);
		inv1.setItem(4, item4);
		inv1.setItem(5, item5);
		inv1.setItem(6, item6);
		inv1.setItem(7, item7);
		inv1.setItem(8, item8);

		p.openInventory(inv1);
		
	}
	
	
	@EventHandler
	public void onSupportInv(InventoryClickEvent e){
		Player p = (Player) e.getWhoClicked();
		
		if(e.getClickedInventory().getName().equalsIgnoreCase("�4Support")){
			e.setCancelled(true);
			
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�eTeleport-Gamemode3")){
				
				String B�sejunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�serjunge = Bukkit.getPlayer(B�sejunge);
				p.teleport(B�serjunge.getLocation());
				p.setGameMode(GameMode.SPECTATOR);
				p.closeInventory();
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�eR�cksto�")){
				
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				B�sererJunge.damage(1); 
				p.sendMessage(Main.Prefux + "�6Spieler bekamm Schaden!");
				p.closeInventory();
				
				
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�eFly=false")){
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				B�sererJunge.setFlying(false);
				p.sendMessage(Main.Prefux + "�6Der Flugmodus wurde f�r den Spieler deaktiviert.");
				p.closeInventory();
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�eWarnung")){
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				B�sererJunge.sendMessage(Main.Prefux + "�6Du wurdest Reportet und verwarnt.Du stehst nun unter beobachtung.");
				p.sendMessage(Main.Prefux + "�6Der Spieler wurde verwarnt.");
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Kick")){
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				B�sererJunge.kickPlayer(Main.Prefux + "�cDu wurdes gekickt.Bitte �ndere dein verhalten oder schalte deine H�cks ab.");
				Bukkit.getServer().broadcastMessage(Main.Prefux + "�6Der Spieler �4" + B�sererJunge.getName() + " �6wurde gekickt.");
				p.closeInventory();
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Tempban-Chatverhalten")){
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tempban " + B�sererJunge.getName() + " 9h Du hast dich nicht angemessen im Chat verhalten.");
				p.closeInventory();
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Tempban-Fly/Speed")){
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "tempban " + B�sererJunge.getName() + " 9d Du hast Fly oder Speed hacks verwendet.");
				p.closeInventory();				
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Ban-Killaura/etc")){
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + B�sererJunge.getName() + " Du hast Killaura oder andere Hacks verwendet und wurdest PERMANENT gebannt.");
				p.closeInventory();
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4IpBan-Severkiller/multiacc+hacking")){
				String B�serjunge = Main.Supportmodus.get(0);
				Main.Supportmodus.remove(0);
				Player B�sererJunge = Bukkit.getPlayer(B�serjunge);
				Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "banip " + B�sererJunge.getName() + " Du hasst den Server angegriffen und oder hast multi accs zum hacken genutzt." );
				p.closeInventory();
			}
		}
		
	}
	
	
	
	
	
	
}
