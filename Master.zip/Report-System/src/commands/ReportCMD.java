package commands;



import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import main.Main;

public class ReportCMD implements CommandExecutor, Listener {
	Inventory inv = Bukkit.createInventory(null, 9, "�4Grund");

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
	Player p = (Player)sender;
		if(sender instanceof Player){
			if(args.length == 1){
		
		    String target = args[0];
		    if(Main.target.size() ==1){
		    	Main.target.remove(0);
		    	System.out.println(Main.Prefux + "�6target List ges�ubert.");
		    }
		    if(Main.�bergang.size() ==1){
		    	Main.�bergang.remove(0);
		    	System.out.println(Main.Prefux + "�6�bergangstarget List ges�ubert.");
		    }
		    if(Main.Sender.size() ==1){
		    	Main.Sender.remove(0);
		    	System.out.println(Main.Prefux + "�6Sender List ges�ubert.");
		    }
		 
		    
			Main.target.add(target);
			System.out.println(Main.Prefux + "Target hinzugef�gt.");
			Main.�bergang.add(target);
			System.out.println(Main.Prefux + "�bergangs Target hinzugef�gt.");
			
			String sender1 = sender.getName();
			Main.Sender.add(sender1);
			System.out.println(Main.Prefux + "Sender hinzugef�gt.");
			openReportGui(p);
		    
				
			} else {
				p.sendMessage(Main.Prefux + "�6Nutze /report <Spieler> oder !report <Spieler>");
			}
			
		}
		return false;
	}

	
	
	public void openReportGui(Player p){
		
		ItemStack item3 = new ItemStack(Material.DIAMOND_SWORD);
    	ItemMeta meta3 = item3.getItemMeta();
    	meta3.setDisplayName("�4Killaura");
    	item3.setItemMeta(meta3);
    	
    	ItemStack item1 = new ItemStack(Material.WEB);
    	ItemMeta meta1 = item1.getItemMeta();
    	meta1.setDisplayName("�4SpawnTrapping");
    	item1.setItemMeta(meta1);
    	
    	ItemStack item2 = new ItemStack(Material.PAPER);
    	ItemMeta meta2 = item2.getItemMeta();
    	meta2.setDisplayName("�4Chatverhalten");
    	item2.setItemMeta(meta2);
    	
    	ItemStack item4 = new ItemStack(Material.IRON_BOOTS);
    	ItemMeta meta4 = item4.getItemMeta();
    	meta4.setDisplayName("�4Kein-R�cksto�");
    	item4.setItemMeta(meta4);
    	
    	ItemStack item5 = new ItemStack(Material.ARROW);
    	ItemMeta meta5 = item5.getItemMeta();
    	meta5.setDisplayName("�4Fly");
    	item5.setItemMeta(meta5);
    	
    	ItemStack item6 = new ItemStack(Material.BOW);
    	ItemMeta meta6 = item6.getItemMeta();
    	meta6.setDisplayName("�4AimBot");
    	item6.setItemMeta(meta6);
    	
    	ItemStack item7 = new ItemStack(Material.BED);
    	ItemMeta meta7 = item7.getItemMeta();
    	meta7.setDisplayName("�4Bedfucker");
    	item7.setItemMeta(meta7);
    	
    	ItemStack item8 = new ItemStack(Material.GLASS_BOTTLE);
    	ItemMeta meta8 = item8.getItemMeta();
    	meta8.setDisplayName("�4Speed");
    	item8.setItemMeta(meta8);
    	
    	ItemStack item9 = new ItemStack(Material.BARRIER);
    	ItemMeta meta9 = item9.getItemMeta();
    	meta9.setDisplayName("�4anderes");
    	item9.setItemMeta(meta9);
    	
    	inv.setItem(0, item1);
    	inv.setItem(1, item2);
    	inv.setItem(2, item3);
    	inv.setItem(3, item4);
    	inv.setItem(4, item5);
    	inv.setItem(5, item6);
    	inv.setItem(6, item7);
    	inv.setItem(7, item8);
    	inv.setItem(8, item9);
    	
    	p.openInventory(inv);
    	}
	@EventHandler
	public void onclick(InventoryClickEvent e){
		
		Player p = (Player)  e.getWhoClicked();
		if(e.getInventory().getName().equalsIgnoreCase("�4Grund")){
			e.setCancelled(true);
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4SpawnTrapping")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4Spawn-Trapping.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
					Main.target.remove(0);
					Main.Sender.remove(0);
					String PlayerR = Main.�bergang.get(0);
					Main.�bergang.remove(0);
					Main.allereports.add("�7" + PlayerR +  " �4Spawn-Trapping�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Chatverhalten")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4Chatverhalten.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR + " �4Chatverhalten�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Killaura")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4Killaura.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR +  " �4Killaura�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Kein-R�cksto�")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4Kein-R�cksto�.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR +  " �4Kein-R�ckstoߧ8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Fly")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4Fly.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR +  " �4Fly�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4AimBot")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4AimBot.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR +  " �4Aimbot�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Bedfucker")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4Bedfucker.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR +  " �4Bedfucker�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4Speed")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4Speed.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR +  " �4Speed�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
			if(e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("�4anderes")){
				for (Player all : Bukkit.getOnlinePlayers()){
					if(all.hasPermission("reportmanager.message")){
						all.sendMessage(Main.Prefux + "�6Der Spieler �a" + Main.Sender.get(0).toString() + " �6hat den Spieler �4" + Main.target.get(0) + " �6reportet f�r �4anderes.");
						all.playSound(all.getLocation(), Sound.HORSE_DEATH, 1F, 1F);
					}
				}
				Main.target.remove(0);
				Main.Sender.remove(0);
				String PlayerR = Main.�bergang.get(0);
				Main.�bergang.remove(0);
				Main.allereports.add("�7" + PlayerR +  " �4anderes�8");
					p.sendMessage(Main.Prefux + "�6Der Spieler wurde reportet!Ein Teammiglied wird gleich zu ihnen sto�en.Bitte geben sie niemanden �ber den Report bescheid!");
					p.closeInventory();
				
			
			}
		}
	}
}
