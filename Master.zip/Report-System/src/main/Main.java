package main;


import java.util.ArrayList;


import org.bukkit.Bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import commands.ClearReports;
import commands.ListReports;
import commands.ReportCMD;
import commands.Support;
import commands.SupportReport;

public class Main extends JavaPlugin{

	public static String Prefux = "�8[�6ReportManager�8]";
	public static ArrayList<String> target = new ArrayList<>();
	public static ArrayList<String> allereports = new ArrayList<>();
	public static ArrayList<String> Sender = new ArrayList<>();
	public static ArrayList<String> �bergang = new ArrayList<>();
	public static ArrayList<String> Supportmodus = new ArrayList<>();
	
	
	public void onEnable(){
		loadCommands();
		loadListener();
		
	}
	
	public void onDisable(){
		
	}
	
	public void loadCommands(){
		getCommand("report").setExecutor(new ReportCMD());
		getCommand("listreports").setExecutor(new ListReports());
		getCommand("clearallreports").setExecutor(new ClearReports());
		getCommand("supportreport").setExecutor(new SupportReport());
		getCommand("supportinv").setExecutor(new Support());
		
	}
	
	public void loadListener(){
		PluginManager pm = Bukkit.getPluginManager();
		pm.registerEvents(new ReportCMD(), this);
		pm.registerEvents(new Support(), this);
	}
}
